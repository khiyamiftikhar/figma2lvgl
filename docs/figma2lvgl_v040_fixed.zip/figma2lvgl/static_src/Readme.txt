This folder contains the static sources to be  added to the generated output
It is just ui_defs.h which needs to be copied to the priv_include directory